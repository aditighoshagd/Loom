package com.loom.postsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
