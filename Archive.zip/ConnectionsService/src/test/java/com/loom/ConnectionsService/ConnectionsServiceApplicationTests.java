package com.loom.ConnectionsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
